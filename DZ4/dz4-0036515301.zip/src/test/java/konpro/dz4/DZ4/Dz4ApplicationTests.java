package konpro.dz4.DZ4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dz4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
