INSERT INTO APP_USER(id, username, hash)
VALUES (1, 'user1', '$2a$12$EJ9YnwOOTW/KP3o9w8p1E.BXdgRoQdG/idFUytJRmj9bdKj7KJeOu'),
       (2, 'user2', '$2a$12$1oCX7U.SYO3aDtOXLfr0beHd02ruXbY7RPJlxqNtmXGV29EPQsCkO'),
       (3, 'user3', '$2a$12$v.3rcJlns/IcN9wczb5iherAcA11iH8NaC578PTpvm6s2KgWFNhQy'),
       (4, 'user4', '$2a$12$Tqg5lZWv2WHtKe2Sm2mOWe/X7t3bKDZykprsv1M1HCqLQTOlrXTmS');
